﻿var Client = require('instagram-private-api').V1;
var device = new Client.Device('someuser');
var storage = new Client.CookieFileStorage('./someuser.json');
var _ = require('underscore');
var Promise = require('bluebird');
var gSession = null;
var sqlIslem = require('./sqlIslem.js');
var http = require('http');
var sql = require('mssql');

creatSession = function () {
        return Client.Session.create(device, storage, 'enguzelenucuz55', '22452245')
            .then(function (session) {
                gSession = session;
            });
}

connector = function () {
    var config = {
        user: 'sa',
        password: '14362245',
        server: '127.0.0.1', // You can use 'localhost\instance' to connect to named instance
        database: 'INSTALAST'

    }
    return new sql.Connection(config);
}

//sabitler
var timerKatsayi = 1;
var likerslimit = 1000;
var comenterslimit = 1000;
//#region COLLECTS JOBS
exports.getUserInfo = function (userId) {
    if (gSession == null) {
        creatSession().then(function () {
            Client.Account.getById(gSession, userId).then(function (data) {
                console.log(data._params.picture)
            });
        })
    }
    else {
        Client.Account.getById(gSession, userId).then(function (data) {
            console.log(data._params.username)
        });
    }
}

exports.getFollowers = function (userId, limit) {
    var connection = connector();
    if (gSession == null) {
        creatSession().then(function () {

            var feed = new Client.Feed.AccountFollowers(gSession, userId, limit);
            feed.all()
                .then(function (data) {
                    connection.connect().then(function () {
                        sqlIslem.insertPool(data, 1, connection);
                    });
                });
        });
    }
    else {
        var feed = new Client.Feed.AccountFollowers(gSession, userId, limit);
        feed.all()
            .then(function (data) {
                connection.connect().then(function () {
                    sqlIslem.insertPool(data, 1, connection);
                });
            });
    }
    
}

exports.getFollows = function (userId, limit) {
    var connection = connector();
    if (gSession == null) {
        creatSession().then(function () {

            var feed = new Client.Feed.AccountFollowing(gSession, userId, limit);
            feed.all()
                .then(function (data) {
                    connection.connect().then(function () {
                        sqlIslem.insertPool(data, 1, connection);
                    });
                });
        });
    }
    else {
        var feed = new Client.Feed.AccountFollowing(gSession, userId, limit);
        feed.all()
            .then(function (data) {
                connection.connect().then(function () {
                    sqlIslem.insertPool(data, 1, connection);
                });
            });
    }

}

getMediaCommenters = function (mediaId, limit) {

    var connection = connector();

    if (gSession == null) {
        creatSession().then(function () {

            var feed = new Client.Feed.MediaComments(gSession, mediaId, limit);
            feed.all()
                .then(function (data) {
                    connection.connect().then(function () {
                        sqlIslem.insertPool(data, 2, connection);
                    });
                });
        });
    }
    else {
        var feed = new Client.Feed.MediaComments(gSession, mediaId, limit);
        feed.all()
            .then(function (data) {
                connection.connect().then(function () {
                    sqlIslem.insertPool(data, 2, connection);
                });
            });
    }

}

getMediaLikers = function (mediaId) {

    var connection = connector();
    if (gSession == null) {
        creatSession().then(function () {

            Client.Media.likers(gSession, mediaId)
                .then(function (likers) {
                    connection.connect().then(function () { 
                        sqlIslem.insertPool(likers, 1, connection);
                    })

                });
        });
        
    }
    else {
        Client.Media.likers(gSession, mediaId)
            .then(function (likers) {
                connection.connect().then(function () {
                    sqlIslem.insertPool(likers, 1, connection);
                })
            });
    }

}

exports.getMediasFromTag = function (tag, limit) {
    if (gSession == null) {
        creatSession().then(function () {
            var feed = new Client.Feed.TaggedMedia(gSession, tag, limit);
            feed.all()
                .then(function (data) {
                    var i = 0
                    function deneme(i) {
                        setTimeout(function () {
                            getMediaLikers(data[i].id);
                            getMediaCommenters(data[i].id, comenterslimit);
                            i += 1;
                            if (data.length != i)
                                deneme(i)
                        }, timerKatsayi * 1000);
                    }
                    deneme(0);
                });
        });
    }
    else {
        var feed = new Client.Feed.AccountFollowers(gSession, userId);
        feed.all()
            .then(function (data) {
                var i = 0
                function deneme(i) {
                    setTimeout(function () {
                        getMediaLikers(data[i].id);
                        getMediaCommenters(data[i].id, comenterslimit);
                        i += 1;
                        if (data.length != i)
                            deneme(i)
                    }, timerKatsayi * 1000);
                }
                deneme(0)
            });
    }
}

exports.getUserMedias = function (userId, limit) {
    if (gSession == null) {
        creatSession().then(function () {

            var feed = new Client.Feed.UserMedia(gSession, userId, limit);
            feed.all()
                .then(function (data) {
                    var i = 0
                    function deneme(i) {
                        setTimeout(function () {
                            getMediaLikers(data[i].id);
                            getMediaCommenters(data[i].id, comenterslimit);
                            i += 1;
                            if (data.length != i)
                                deneme(i)
                        }, timerKatsayi * 1000);
                    }
                    deneme(0);
                    
                });
        });
    }
    else {
        var feed = new Client.Feed.UserMedia(gSession, userId, limit);
        feed.all()
            .then(function (data) {
                var i = 0
                function deneme(i) {
                    setTimeout(function () {
                        getMediaLikers(data[i].id);
                        getMediaCommenters(data[i].id, comenterslimit);
                        i += 1;
                        if (data.length != i)
                            deneme(i)
                    }, timerKatsayi * 1000);
                }
                deneme(0);
            });
    }
}

exports.getTimeLineMedias = function (limit) {
    if (gSession == null) {
        creatSession().then(function () {

            var feed = new Client.Feed.Timeline(gSession, limit);
            feed.all()
                .then(function (data) {
                    _.each(data, function (media) {
                        console.log(media.id);
                    })
                });
        });
    }
    else {
        var feed = new Client.Feed.Timeline(gSession, limit);
        feed.all()
            .then(function (data) {
                _.each(data, function (media) {
                    console.log(media.id);
                })
            });
    }
}

//#region birlestirilecek
getLocationId = function (locationText) {
    creatSession().then(function () {
        Client.Location.search(gSession, locationText).then(function (locData) {
            console.log(locData[0].id);
        })
    });
}

exports.getMediasFromLocation = function (locationId, limit) {
    var connection = connector();
    if (gSession == null) {
        creatSession().then(function () {
            var feed = new Client.Feed.LocationMedia(gSession, locationId, limit);
            feed.all()
            .then(function (data) {
                connection.connect().then(function () {
                    sqlIslem.insertPool(data, 2, connection);
                });
            });
        });
    }
    else {
        var feed = new Client.Feed.LocationMedia(gSession, locationId, limit);
        feed.all()
            .then(function (data) {
                connection.connect().then(function () {
                    sqlIslem.insertPool(data, 2, connection);
                });
            });
    }
}
//#endregion

//#endregion

//#region JOBS
exports.doLike = function (mediId) {
    if (gSession == null) {
        creatSession().then(function () {
            Client.Like.create(gSession, mediId).then(function (data) {
                console.log(data);
            });
        });
    }
    else {
        Client.Like.create(gSession, mediId).then(function (data) {
            console.log(data);
        });
    }
}

exports.doUnLike = function (mediId) {
    if (gSession == null) {
        creatSession().then(function () {
            Client.Like.destroy(gSession, mediId).then(function (data) {
                console.log(data);
            });
        });
    }
    else {
        creatSession().then(function () {
            Client.Like.destroy(gSession, mediId).then(function (data) {
                console.log(data);
            });
        });
    }
}

exports.doComment = function (mediaId, commentText) {
    if (gSession == null) {
        creatSession().then(function () {
            Client.Comment.create(gSession, mediaId, commentText)
                .then(function (comment) {
                    // this 'then' block should be always resolved with successfully placed comment
                    console.log(comment);
                })
                .catch(Client.Exceptions.NotFoundError, function (e) {
                    // Medium was not found
                    console.error(error);
                })
                .catch(function (e) {
                    console.error(e) // this will catch all errors
                })
        });
    }
}

exports.sendDirectMessage = function (userIds, directText) {
    if (gSession == null) {
        creatSession().then(function () {

            Client.Thread.configureText(gSession, userIds, directText)
                .then(function (threads) {
                    //var thread = threads[0];
                    //thread.broadcastText("second text you can send directly from thread instance");
                    console.log(threads[0].items) // -> see conversation
                });
        });
    }
}

exports.uploadPhoto = function (path, caption) {
    if (gSession == null) {
        creatSession().then(function () {
            var pathOrStream = path;
            return [Client.Upload.photo(gSession, pathOrStream), gSession]
            })
            .spread(function (upload, gSession) {
                return Client.Media.configurePhoto(gSession, upload.params.uploadId, caption)
            })
            .then(function (medium) {
                console.log(medium) // -> return Instance of Client.Media
            })
       
    }
   

}

exports.doFollow = function (userId) {

    if (gSession == null) {
        creatSession().then(function () {
            Client.Relationship.create(gSession, userId).then(function (data) {
                console.log(data._params.following)
            });
        })
           

    }

}

exports.doUnFollow = function (userId) {

    if (gSession == null) {
        creatSession().then(function () {
            Client.Relationship.destroy(gSession, userId).then(function (data) {
                console.log(data._params.following)
            });
        })


    }

}

//#endregion


