﻿var sql = require('mssql');
var _ = require('underscore');
var request = require("request")
var rp = require('request-promise');
var Promise = require('bluebird');
var genderize = require('genderize')

connector = function () {
    return sql.connect("mssql://sa:14362245@127.0.0.1/INSTALAST");
}



//#region GETGENDER
getGender = function (name) {
    var fullName = name.replace(/[^ İıÇçÜüöÖŞşğĞa-zA-Z]/gi, ' ').replace(/\s+/g, ' ').trim().split(/\s/g);
    
    if (fullName[1] == '' || fullName[1] == undefined)
        fullName[1] = 'x';

    if ((fullName[0] == '' || fullName[0] == undefined) && fullName[1] != 'x')
        fullName[0] = fullName[1];

    console.log(name + ":" + fullName[0] + ' ' + fullName[1])
    var options = {
        uri: "http://api.namsor.com/onomastics/api/json/gender/" + fullName[0] + "/" + fullName[1],
        json: true // Automatically parses the JSON string in the response
    };

    return rp(options);
}
//#endregion

getFiltersResult = function (user, filtersData) {
    var result = true;
    if (filtersData.gender.active) {
        return getGender(user._params.fullName + ' ' + user._params.username).then(function (data) {
            if (data.gender == filtersData.gender.value)
                result = result & true;
            else
                result = false;

            if (filtersData.private.active) {
                if (filtersData.private.value == user._params.isPrivate)
                    result = result & true;
                else
                    result = false;
            }

            if (filtersData.profilpicture.active) {
                if (!filtersData.profilpicture.value == Boolean(user._params.hasAnonymousProfilePicture))
                    result = result & true;
                else
                    result = false;
            }

            return new Promise(function (resolve) {
                resolve(result);
            });
        }).catch(function (e) {
            console.log("handled the error");
        });
    }
    else {
        if (filtersData.private.active) {
            if (filtersData.private.value == user._params.isPrivate)
                result = result & true;
            else
                result = false;
        }

        if (filtersData.profilpicture.active) {
            if (!filtersData.profilpicture.value == Boolean(user._params.hasAnonymousProfilePicture))
                result = result & true;
            else
                result = false;
        }

        return new Promise(function (resolve) {
            resolve(result);
        });
    } 
}


var kullaniciid = 1;
exports.insertPool = function (data, type, connection, filtersData) {
    if (data.length > 0) {
        var filters = {
            "gender": {
                "active": true,
                "value": "female"
            },
            "private": {
                "active": true,
                "value": false
            },
            "profilpicture": {
                "active": true,
                "value": true
            },
        }

        if (type == 1) {
            var i = 0
            function deneme(i) {
                    account = data[i];
                    getFiltersResult(account, filters).then(function (result) {
                        if (result) {
                            var request = new sql.Request(connection);
                            request.input('KULLANICI_ID', sql.Int, kullaniciid);
                            request.input('INSTAGRAM_ID', sql.VarChar(50), account._params.id);
                            request.input('INSTAGRAM_NAME', sql.VarChar(50), account._params.username);
                            request.execute('SP_INSERT_HAVUZ').then(function (recordsets) {
                            }).catch(function (err) {
                                console.dir(err)
                            });
                        }
                        i += 1;
                        if (data.length != i)
                            deneme(i)
                    });
            }
            deneme(0);
            
        }

        if (type == 2) {
            var i = 0
            function deneme(i) {
                var account = data[i];
                getFiltersResult(account.account, filters).then(function (result) {
                    if (result) {
                        var request = new sql.Request(connection);
                        request.input('KULLANICI_ID', sql.Int, kullaniciid);
                        request.input('INSTAGRAM_ID', sql.VarChar(50), account.account._params.id);
                        request.input('INSTAGRAM_NAME', sql.VarChar(50), account.account._params.username);
                        request.execute('SP_INSERT_HAVUZ').then(function (recordsets) {
                        }).catch(function (err) {
                            console.dir(err)
                        });
                    }
                    if (data.length != i)
                        deneme(i + 1)
                });
            }
            deneme(0);
            
        }
    }
}



