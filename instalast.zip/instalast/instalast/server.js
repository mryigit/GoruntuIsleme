var http = require('http');
var express = require('express');
var bodyParser = require('body-parser');
var path = require('path');
var botIslem = require('./Server/BotIslem.js');
var port = process.env.port || 1337;
var app = express();
app.use(bodyParser());
app.get('/instalast', function (request, response) {
    response.sendfile("views/index.html");
});
//botIslem.getUserInfo('4204374332');
botIslem.getFollowers('1365073321', 4000);
botIslem.getFollows('1365073321', 10000);
botIslem.getMediasFromTag('love', 30);
botIslem.getUserMedias('1365073321', 30);
//botIslem.getTimeLineMedias(10);
//botIslem.getMediasFromLocation('216151289', 1000);
//botIslem.doLike('1394975661726596953');
//botIslem.doComment('1394975661726596953', 'deneme');
//botIslem.sendDirectMessage(['1606397011', '1943646464'], 'toplu deneme mesajı');
//botIslem.uploadPhoto('C:\\Users\\BILGIISLEM\\Desktop\\resim.jpg', 'deneme');
//botIslem.doFollow('1606397011');
//botIslem.doUnFollow('1606397011');
app.get('/instalast/api/getUserInfo', botIslem.getUserInfo);
app.use('/instalast', express.static(path.join(__dirname, 'public')));
app.listen(port);
//# sourceMappingURL=server.js.map